/*
 * GccApplication8.c
 *
 * Created: 09-Jan-20 10:26:57 AM
 *  Author: NIC
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}