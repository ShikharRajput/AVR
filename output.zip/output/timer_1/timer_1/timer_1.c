/*
 * timer_1.c
 *
 * Created: 16-Jan-20 9:18:12 AM
 *  Author: NIC
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}